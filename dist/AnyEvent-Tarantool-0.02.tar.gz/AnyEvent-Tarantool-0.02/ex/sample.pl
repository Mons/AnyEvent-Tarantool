#!/usr/bin/env perl
use AnyEvent::Tarantool;

...

